import { Button, Container } from "react-bootstrap";
import { Row } from "react-bootstrap";
import type { ApiResponse, Bread, Pagination } from "../type/state";
import { useState, useEffect } from "react";
import axios from "axios";
import BreadTableHeader from "../ui/breadTblHeader";
import BreadTblBody from "../ui/breadTblBody";
const API_URL = "https://dogapi.dog/api/v2/breeds";
const Animals = () => {
    const [displayList, setDisplayList] = useState<Bread[]>([]);
    const [pagination, setPagination] = useState<Pagination | null>(null);
    const [page, setPageNumber] = useState<number>(1);
    const [pageSize, setPageSize] = useState<number>(6);
    const getURL = (pageNumber: number, size: number) => {
        const param = new URLSearchParams();
        param.set('page[number]', String(pageNumber));
        param.set('page[size]', String(size));
        return `${API_URL}?${param.toString()}`;
    }
    useEffect(() => {
        getList();
    }, [page])
    const getList = async () => {
        const urls = getURL(page, pageSize);
        const resss = axios.get(`${API_URL}?`, {params:{"page[number]":page,"page[size]":pageSize}});
        console.log(resss);
        try {
            fetch(urls).then((res) => {
                return res.json();
            }).then((data: ApiResponse) => {
                console.log(data);
                setDisplayList(data?.data);
                setPagination(data?.meta?.pagination);
            });
        } catch (error) {
            console.log(error);
        }
        //console.log(respinse);

    }
    const pageHandler = (idx: number) => {
        console.log(idx);
        setPageNumber(idx);
    }
    
    return (
        <Container>
            <BreadTableHeader/>           
           
            {
                displayList && displayList.length > 0 && displayList.map((item, index) => {
                    
                    return(<BreadTblBody item={item}/>)
                //     return (
                //         <Row className='row  border-bottom border-dark padding-row p-2' key={`${item.id}`}>
                //             <div className='col-1'>{item?.type}</div>
                //             <div className='col-2'>{item?.attributes?.name}</div>
                //             <div className='col-4' title={item.attributes?.description}>{item.attributes?.description.substring(0, 90)}{"..."}</div>
                //             <div className='col-1'>{item.attributes?.life?.max} {item.attributes?.life?.min}</div>
                //             <div className='col-2'> {"max:"}{item.attributes?.male_weight?.max} {"min:"}{item.attributes?.male_weight?.min}</div>
                //             <div className='col-2'>{"max:"}{item?.attributes?.female_weight?.max},{"min:"}{item?.attributes?.female_weight?.min}</div>
                //         </Row>
                //     )
                 })
            }
            <Row className="row  border-bottom border-dark padding-row p-2">
                <div className='col-12'>                    
                    {pagination?.first?<Button  onClick={_e => pageHandler(pagination?.prev)} className="mrgin-r">First</Button> : <Button disabled={page === pagination?.current ? true : false} className="mrgin-r">Current</Button>} {" "}
                    {pagination?.prev ? <Button onClick={_e => pageHandler(pagination?.prev)} className="mrgin-r">Prev</Button> : ''} {" "}
                    {pagination?.next ? <Button onClick={_e => pageHandler(pagination?.next)} className="mrgin-r">Next</Button> : ''}{" "} 
                    {pagination?.last ? <Button onClick={_e => pageHandler(pagination?.last)} className="mrgin-r">Last</Button> : ''}
                </div>
            </Row>
            <Row>

            </Row>

        </Container>
    )

}

export default Animals;
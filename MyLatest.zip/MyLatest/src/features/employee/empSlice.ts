
import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { emp } from "../../type/state";
import api from "../../services/apiServices";
import { deleteEmployee,getEmployee, insertEmployee } from "../empThunks";
type InsertPayload = { id: 'insert'; values: emp };
type UpdatePayload = { id: 'update'; values: { id: string; changes: Partial<emp> } };
type DeletePayload = { id: 'delete'; values: { id: string } };
type GetPayload = { id: 'get'; values: emp[] };
type GetDataPayload = InsertPayload | UpdatePayload | DeletePayload | GetPayload;

export interface InsertState {
    employees: emp[];

}

const initialState: InsertState = {
    employees: [],
};

const employeeSlice = createSlice({
    name: "Employee",
    initialState,
    reducers: {
        getData(state, action: PayloadAction<GetDataPayload>) {   

            switch (action.payload.id) {
                case 'insert': {
                    const res = api.post('/employee', action.payload.values);
                    state.employees = [...state.employees, action.payload.values];
                    break;
                }

                case 'update': {

                    break;
                }

                case 'delete': {                    
                    const { id } = action.payload.values;
                    const res = api.delete(`/employee/${id}`);
                    state.employees = state.employees.filter(e => e.id !== id);                    
                    break;
                }

                case 'get': {                    
                    //state.employees = action.payload.values;                  
                    break;
                }
            }


        },

        reset() {
            return initialState;
        },
        
        clearEmployee: (state) => {
            state.employees = []           
    },

    },
    extraReducers:(builder)=>{
      builder
      .addCase(getEmployee.pending,(state)=>{
      })
      .addCase(getEmployee.fulfilled,(state,action)=>{
        state.employees = action.payload;
      })
      .addCase(deleteEmployee.pending,(state)=>{

      }).addCase(deleteEmployee.fulfilled,(state,action)=>{
       // console.log(state.employees);
        const deletedId = action.payload;
         state.employees = state.employees.filter(e => e.id !== deletedId.id)
      }) 
      .addCase(insertEmployee.pending,(state)=>{

      }).addCase(insertEmployee.fulfilled,(state,action)=>{
        state.employees =[...state.employees,action.payload];
      }) 
    }
});

export const { getData, reset,clearEmployee } = employeeSlice.actions;
export default employeeSlice.reducer;

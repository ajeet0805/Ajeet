import { createAsyncThunk } from "@reduxjs/toolkit";
import type { emp } from "../type/state";
const EMP_URL = 'http://localhost:9999/employee';
export const getEmployee = createAsyncThunk<emp[]>(
    '/employee',
    async () => {
        const res = await fetch(EMP_URL);
        if (!res.ok) throw new Error('Failed to fetch users')
        return (await res.json()) as emp[]
    }
    )
  export const deleteEmployee = createAsyncThunk<emp,
   {id: string }
  >(
    '/employee/delete',
    async({id})=> {
        const res = await fetch(`${EMP_URL}/${id}`,{ method: 'DELETE'});
         if (!res.ok) throw new Error('Failed to fetch users')
        return (await res.json()) as emp
    }
  )  

  export const insertEmployee =createAsyncThunk<emp,{values:emp}>(
   '/employee/Add',
   async({values})=>{
        const res = await fetch(EMP_URL,
        {
        method: 'POST',        
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
        }
      )
     return (await res.json()) as emp
   }
  )
//export default {getEmployee , deleteEmployee};
import Button from 'react-bootstrap/Button';
import type { stateMgt, erroFlag, flag, total } from '../type/state';
import { useEffect, useState } from 'react';
import api from '../services/apiServices';
import Container from 'react-bootstrap/Container';
import { Row, Col } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import TxtFooter from '../ui/txtFooter';
import TxtTableHeader from './txtTableHeader';
import TotalBalance from '../ui/totalBalance';
import { useFormik } from 'formik';
//import Modal from 'react-bootstrap/Modal';
import * as Yup from "yup";
import TxtModel from '../ui/txtModel';
const StateManageMent = () => {
    const [stateManage, setStateManage] = useState<stateMgt[]>([]);
    const [TxtState, setTxtState] = useState<stateMgt[]>([]);
    const [formField, setFormField] = useState<stateMgt>({ transdate: '', header: '', credit: '', debit: '' });
    const [editField, setEditField] = useState<stateMgt>({ transdate: '', header: '', credit: '', debit: '' });
    const [errorFlag, setErrorFlag] = useState<erroFlag>({ dotFlg: false, creditFlag: false, headerFlag: false, debitFlag: false });
    const [flag, setFlag] = useState<boolean>(false);
    const [editFlag, setEditFlag] = useState<flag>({ flg: false });
    const [nIdx, setNIdx] = useState<string>('');
    const [total, setTotal] = useState<total>({ credit: 0, debit: 0, balance: 0 });
    const [errorMsg, setErrorMsg] = useState<string>('');
    const [isEditFlag, setIsEditFlag] = useState<boolean>(false);

    const initialValues: stateMgt = {
        transdate: "",
        header: "",
        credit: "",
        debit: ""
    };

    const schema = Yup.object({
        transdate: Yup.string().required("Transation date is required"),
        header: Yup.string().required('Header is required'),
        credit: Yup.number().optional(),
        debit: Yup.number().optional(),

    });
    const formik = useFormik<stateMgt>({
        initialValues,
        validationSchema: schema,
        onSubmit: async (values: stateMgt) => {
            try {
                //await new Promise((res) => setTimeout(res, 500));
                postData(values);
                console.log("Submitted:", values);
            } finally {
                //helpers.setSubmitting(false);
            }
        },
    });
    const { values, errors, handleSubmit, handleChange, touched } = formik;
    const fetchAPI = async () => {
        try {
            const res = await api.get('/trans'); console.log(res?.data);
            setStateManage(res?.data);
            totalSum(res?.data);
            setFlag(false);
            setErrorMsg('');
        } catch (error) {
            console.log(error);
            setErrorMsg('Unable to fetch reocrd ! please try letter');
        }

    };

    useEffect(() => {
        fetchAPI();
    }, [flag]);

    const deleteHandler = async (Idx: string) => {
        try {
            const response = await api.delete(`/trans/${Idx}`);
            setFlag(true);
            //setStateManage(response?.data); console.log(response);
        } catch (error) {
            console.log("___")
        }


    }
    const changeHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        //console.log(name, value);
        setFormField(formField => ({ ...formField, [name]: value }));
    }
    const changeHandler1 = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        //console.log(name, value);
        setEditField(editField => ({ ...editField, [name]: value }));
    }
    const submitHandler = (e: any) => {
        e.preventDefault();
        const dotFlag = formField.transdate === '';
        setErrorFlag(errorFlag => ({ ...errorFlag, dotFlg: dotFlag }));
        const headers: boolean = formField.header.trim() === '' || formField.header.trim() === null;
        setErrorFlag(errorFlag => ({ ...errorFlag, headerFlag: headers }));        // }
        const credit: boolean = formField.credit === '' || formField.credit === null;
        const debit: boolean = formField.debit === '' || formField.debit === null;
        setErrorFlag(errorFlag => ({ ...errorFlag, creditFlag: credit && debit }));
        setErrorFlag(errorFlag => ({ ...errorFlag, debitFlag: credit && debit }));
        if (dotFlag || headers) {
            return false;
        }
        if (credit && debit) {
            return false;
        }

        //postData(formField);
        //}

    }

    const postData = async (formField: stateMgt) => {
        try {
            // POST request
            const response = await api.post('/trans', formField);
            // console.log('Posted data:', response.data);
            setStateManage(stateManage => [...stateManage, response.data]);
            totalSum(stateManage);
        } catch (error) {
            console.error('Error posting data:', error);
        }
    };



    const editHandler = (idx: string) => {
        //setEditFlag(true);
        setNIdx(idx);
        const resss: stateMgt[] = stateManage?.filter(item => item.id === idx);
        //console.log(resss[0]);
        setEditField(resss[0]);
        setIsEditFlag(true);
    }

    const updateHandler = async (uIdx: string) => {
        try {
            // POST request
            const response = await api.put(`/trans/${uIdx}`, editField);
            //console.log('Posted data:', response.data);
            setNIdx('');
            //setStateManage(stateManage => [...stateManage, response.data]);
            setStateManage(stateManage.map((items: stateMgt) => items.id === uIdx ? editField : items));
        } catch (error) {
            console.error('Error posting data:', error);
        }
    }

    const cancelHandler = (idx: string) => {
        setNIdx('');
        setEditFlag({ flg: false });
    }

    const totalSum = (arr: stateMgt[]) => {
        //console.log("", stateManage);
        const sum: any = arr.filter((itr: stateMgt) => itr.credit).map(a => a.credit).reduce((a1: any, b2: any) => parseInt(a1) + parseInt(b2), 0);
        const sum1: any = arr.filter((itr: stateMgt) => itr.debit).map(a => a?.debit !== ' ' ? a.debit : 0).reduce((a1: any, b2: any) => parseInt(a1) + parseInt(b2), 0);
        const TotalSum: any = sum - sum1;
        setTotal(total => ({ ...total, credit: sum }));
        setTotal(total => ({ ...total, debit: sum1 }));
        setTotal(total => ({ ...total, balance: TotalSum }));
        console.log(sum, sum1);
    }
    const handleClose=()=>{
        setIsEditFlag(false);
    }
    return (<>    

    <TxtModel isEditFlag={isEditFlag} handleClose={handleClose}/> 
        <Container>            
            <Form onSubmit={handleSubmit}>
                <Row className="mb-12 mt-3">
                    <Col sm="2">
                        <Form.Control type="date" value={values.transdate} name="transdate" id="transdate" placeholder="Date of Transaction" onChange={handleChange} />
                        {touched.transdate && errors.transdate && <Form.Text id="transdate" muted>Sometging went wrong!</Form.Text>}

                    </Col>
                    <Col sm="2">
                        <Form.Control type="text" value={values.header} name="header" id="header" placeholder="Header" onChange={handleChange} />
                        {touched.header && errors.header && <Form.Text id="header" muted className='warning'>Sometging went wrong!</Form.Text>}

                    </Col>
                    <Col sm="3">
                        <Form.Control type="text" value={values.credit} name="credit" id="credit" placeholder="Credit" onChange={handleChange} />
                        {touched.credit && errors.credit && <Form.Text id="credit" muted>Sometging went wrong!</Form.Text>}
                    </Col>
                    <Col sm="2">
                        <Form.Control type="text" value={values.debit} name="debit" id="debit" placeholder="Debit" onChange={handleChange} />
                        {touched.debit && errors.debit && <Form.Text id="debit" muted>Sometging went wrong!</Form.Text>}
                    </Col>
                    <Col sm="2">
                        <Button type="submit"><i className='bi bi-plus-square-fill'></i></Button>
                    </Col>
                </Row>
            </Form>

           
            {/* {errorMsg && (
            <Row>
                <div className="alert alert-danger " role="alert" style={{"marginTop":"10px"}}>
                    {errorMsg}
                </div>
            </Row>)} */}
            <TxtTableHeader />
            {
                stateManage && stateManage.length > 0 && stateManage?.map((item: stateMgt, index: number) => {
                    return (                       
                        <Row className='row  border-bottom border-dark padding-row p-2' key={`${item.transdate}${item.id}`}>
                        <div className='col-3'>{nIdx !== item.id ? item.transdate : <Form.Control type="date" value={editField.transdate} name="transdate" id="transdate" placeholder="Date of Transaction" onChange={changeHandler1} />}</div>
                        <div className='col-2'>{nIdx !== item.id ? item.header : <Form.Control type="text" value={editField.header} name="header" id="header" placeholder="Header" onChange={changeHandler1} />}</div>
                        <div className='col-2'>{nIdx !== item.id ? item.credit : <Form.Control type="text" value={editField.credit} name="credit" id="credit" placeholder="Credit" onChange={changeHandler1} />}</div>
                        <div className='col-2'>{nIdx !== item.id ? item.debit : <Form.Control type="text" value={editField.debit} name="debit" id="debit" placeholder="Debit" onChange={changeHandler1} />}</div>
                        <div className='col-3'>{nIdx !== item.id ? <><Button variant="primary" onClick={() => editHandler(item?.id ? item.id : '')}><i className='bi bi-pen' title='Edit'></i></Button> <Button variant="danger" onClick={() => deleteHandler(item.id ? item.id : '')}><i className='bi bi-trash' title='Edit'></i></Button></> : <><Button variant="success" onClick={() => updateHandler(item?.id ? item.id : '')}><i className='bi bi-save' title='Save'></i></Button> <Button variant="info" onClick={() => cancelHandler(item?.id ? item.id : '')}><i className='bi bi-x-circle' title='Cancel'></i></Button></>}</div>
                        </Row>
                    )
                })}
            <TotalBalance total={total} />
            <TxtFooter total={total} />
        </Container>
                        
    </>);
}

export default StateManageMent;
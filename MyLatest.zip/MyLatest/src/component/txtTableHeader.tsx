import { Row } from "react-bootstrap";

const TxtTableHeader=()=>{
           return(
                <Row className='row border-bottom border-dark p-2 mb-2 bg-primary text-white' style={{"marginTop":"10px"}}>
                <div className='col-3'>Date of Transation</div>
                <div className='col-2'>Header</div>
                <div className='col-2'>Credit</div>
                <div className='col-2'>Debit</div>
                <div className='col-3'>Action</div>
             </Row>)
}

export default TxtTableHeader;
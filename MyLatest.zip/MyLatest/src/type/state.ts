export interface stateMgt{
    transdate:string,
    header:string,
    credit?:number | string | "",
    debit?:number | string | "",
    id?:string,
    isEditable?:boolean;
}
export interface erroFlag{
    dotFlg:boolean,
    headerFlag:boolean,
    creditFlag:boolean,
    debitFlag:boolean,
    
}
export interface flag {
    flg:boolean
}
export interface total{
    credit:number,
    debit:0,
    balance:0
}
export interface emp {
    id?:string,
    employee:string,
    dept:string,
    header:string,
    credit:number,
    debit:number,
    date:string
}
/*These interface are used in Animals */
export interface dimens{
    min:number,
    max:number
}
export interface Bread {
    id:string;
    type:"bread",
    attributes:{
        name:string,
        description:string,
        life:dimens,
        male_weight:dimens,        
        female_weight:dimens,
        hypoallergenic:boolean
    }
}
export interface ApiResponse {
    data:Bread[],
    link?:unknown,
    meta:Meta
}
export interface Pagination {
      current: number,
      next: number,
      last: number,
      records: number,
      first:number,
      currect:number,
      prev:number

}
export interface Meta{
    pagination:Pagination
}


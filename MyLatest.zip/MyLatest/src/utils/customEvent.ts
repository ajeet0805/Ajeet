const API_URL = "https://dogapi.dog/api/v2/breeds";
export const apiRUL = (pageNumber:number, size:number)=>{
                const URL = new URLSearchParams();
                URL.set('page[number]',String(pageNumber));
                URL.set('page[size]',String(size));               
                return `${API_URL}?${URL.toString()}`;
    }

    
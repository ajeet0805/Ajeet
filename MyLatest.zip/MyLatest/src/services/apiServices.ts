import axios from "axios";

const api = axios.create({
    baseURL: 'http://localhost:9999',
    headers: {
        'Content-Type': 'application/json'
    },
});
// request interceptor

api.interceptors.request.use((config) => {   
    return config;
}, (error) => {
    return Promise.reject(error);
}
);
// response interceptor
api.interceptors.response.use((response) => {
    return response;
});

export default api;

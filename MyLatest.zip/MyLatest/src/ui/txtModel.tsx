 import { useState } from "react";
import { Modal } from "react-bootstrap";
 import Button from "react-bootstrap/Button";


 const TxtModel=({isEditFlag,handleClose}:{handleClose:()=>void,isEditFlag:boolean})=>{
    const [modelTxt,setModelTxt] = useState({show:false,title:'',message:''});
    // const handleClose=()=>{

    // }
    const handleConfirm=()=>{

    }
    return(
    <Modal show={isEditFlag} onHide={handleClose} backdrop="static" keyboard={false}>
      <Modal.Header closeButton>
        <Modal.Title>{modelTxt.title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{modelTxt.message}</Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="danger" onClick={handleConfirm}>
          Confirm
        </Button>
      </Modal.Footer>
    </Modal>
    )
 }

 export default TxtModel
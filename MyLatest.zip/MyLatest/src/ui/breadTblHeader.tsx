import { Row } from "react-bootstrap";
const BreadTableHeader = () => {
    return(
    <Row className='p-2 mb-2 bg-dark text-white'>
        <div className='col-1'>Type</div>
        <div className='col-2'>Name</div>
        <div className='col-4'>Description</div>
        <div className='col-1'> Life</div>
        <div className='col-2'> Male Weight</div>
        <div className='col-2'> Female weight</div>
    </Row>
    )
}


export default BreadTableHeader;
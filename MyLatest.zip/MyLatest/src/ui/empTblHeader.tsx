import { Row } from "react-bootstrap";

const EmpTblHeader=()=>{
    return(
        <Row className='p-2 mb-2 bg-dark text-white' style={{marginTop:'10px'}}>
        <div className='col-2'>Date</div>
        <div className='col-2'>Header</div>
        <div className='col-2'>Emp Dept</div>
        <div className='col-2'> Creit</div>
        <div className='col-2'> Debit</div>
        <div className='col-2'>Action
           
        </div>
        </Row>
    )
}

export default EmpTblHeader;
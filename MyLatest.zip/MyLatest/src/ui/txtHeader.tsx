import { Navbar,Container } from "react-bootstrap";
//import Routers from "../route/routers";
const TxtHeader=()=>{
    return(<>
    <Navbar bg="primary" data-bs-theme="dark">
            <Container>
                <Navbar.Brand href="#home">State Management</Navbar.Brand>
            </Container>
        </Navbar>
    </>)
}

export default TxtHeader;
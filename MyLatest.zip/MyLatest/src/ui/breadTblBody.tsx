import { Row } from "react-bootstrap";
import type { Bread } from "../type/state";

const BreadTblBody = ({ item }: { item: Bread }) => {
    return (
        <Row className='row  border-bottom border-dark padding-row p-2' key={`${item.id}`}>
            <div className='col-1'>{item?.type}</div>
            <div className='col-2'>{item?.attributes?.name}</div>
            <div className='col-4' title={item.attributes?.description}>{item.attributes?.description.substring(0, 90)}{"..."}</div>
            <div className='col-1'>{item.attributes?.life?.max} {item.attributes?.life?.min}</div>
            <div className='col-2'> {"max:"}{item.attributes?.male_weight?.max} {"min:"}{item.attributes?.male_weight?.min}</div>
            <div className='col-2'>{"max:"}{item?.attributes?.female_weight?.max},{"min:"}{item?.attributes?.female_weight?.min}</div>
        </Row>
    )
}

export default BreadTblBody;
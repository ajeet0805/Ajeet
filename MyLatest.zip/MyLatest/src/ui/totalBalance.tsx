import { Row } from "react-bootstrap";
import type { total } from "../type/state";

const TotalBalance=({total}:{total:total})=>{
    return( <Row className='row  border-bottom border-dark padding-row p-2'>
                <div className='col-3'></div>
                <div className='col-2'><strong>Total</strong></div>
                <div className='col-2'><strong>{total.credit}</strong></div>
                <div className='col-2'><strong>{total?.debit}</strong></div>
                <div className='col-3'></div>
            </Row>)
}

export default TotalBalance;
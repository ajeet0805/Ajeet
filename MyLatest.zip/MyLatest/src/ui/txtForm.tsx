import { Form } from "react-bootstrap";
import {Row, Col} from "react-bootstrap";
import type { stateMgt } from "../type/state";
import Button from "react-bootstrap/Button";
const TxtForm =({formik}:{childProps})=>{
    return(
        <Form onSubmit={handleSubmit}>
                <Row className="mb-12 mt-3">
                    <Col sm="2">
                        <Form.Control type="date" value={values.transdate} name="transdate" id="transdate" placeholder="Date of Transaction" onChange={handleChange} />
                        {touched.transdate && errors.transdate && <Form.Text id="transdate" muted>Sometging went wrong!</Form.Text>}

                    </Col>
                    <Col sm="2">
                        <Form.Control type="text" value={values.header} name="header" id="header" placeholder="Header" onChange={handleChange} />
                        {touched.header && errors.header && <Form.Text id="header" muted className='warning'>Sometging went wrong!</Form.Text>}

                    </Col>
                    <Col sm="3">
                        <Form.Control type="text" value={values.credit} name="credit" id="credit" placeholder="Credit" onChange={handleChange} />
                        {touched.credit && errors.credit && <Form.Text id="credit" muted>Sometging went wrong!</Form.Text>}
                    </Col>
                    <Col sm="2">
                        <Form.Control type="text" value={values.debit} name="debit" id="debit" placeholder="Debit" onChange={handleChange} />
                        {touched.debit && errors.debit && <Form.Text id="debit" muted>Sometging went wrong!</Form.Text>}
                    </Col>
                    <Col sm="2">
                        <Button type="submit"><i className='bi bi-plus-square-fill'></i></Button>
                    </Col>
                </Row>
            </Form>
    )
}

export default TxtForm;
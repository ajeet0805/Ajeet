import { Route, Routes, BrowserRouter as MyRoute } from "react-router-dom";
import StateManageMent from "../component";
import EmployeeData from "../employee/employee";
import { Container, Nav } from "react-bootstrap";
import {Row} from "react-bootstrap";
import Animals from "../animals/animal";

const Routers = () => {   
    return (<>
        <MyRoute>
            <Container>
            <Row>
            <Nav>               
                <Nav.Item>
                    <Nav.Link href="/">  Statemenet  </Nav.Link>                    
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link href="/employee">Employee</Nav.Link> 
                </Nav.Item>   
                <Nav.Item>
                    <Nav.Link href="/breads">Animals</Nav.Link> 
                </Nav.Item>          
             </Nav>
           
            </Row>
            </Container>
            <Routes>
                <Route path="/" element={<StateManageMent/>}></Route>
                <Route path="/employee" element={<EmployeeData/>}></Route>
                <Route path="/breads" element={<Animals/>}></Route>
            </Routes>
        </MyRoute>
    </>)
}

export default Routers;
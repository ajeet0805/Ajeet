import { Container, Form, Row } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import { useEffect, useState } from "react";
import type { emp } from "../type/state";
//import api from "../services/apiServices";
import EmpTblHeader from "../ui/empTblHeader";
import {getEmployee,deleteEmployee,insertEmployee} from "../features/empThunks";
//import { deleteEmployee } from "../features/empThunks";
//import { apiRUL } from "../utils/customEvent";
import * as Yup from "yup";
import { useFormik } from "formik";

import { useAppDispatch, useAppSelector } from "../features/employee/hooks";
import { getData } from "../features/employee/empSlice";

const EmployeeData = () => {
    const emps = useAppSelector((state) => state.employees);
    console.log(emps);
    const dispatch = useAppDispatch();
    const [employeeList, setEmployeeLit] = useState<emp[]>([]);
    const initialValues: emp = {
        debit: 0,
        credit: 0,
        date: '',
        dept: '',
        header: '',
        employee: ''
    };
    const schems = Yup.object({
        employee: Yup.string().required("Something wen wrong"),
        header: Yup.string().required("Something wen wrong"),

    });
    const formik = useFormik<emp>({
        initialValues,
        validationSchema: schems,
        onSubmit: async (values: emp) => {
            try {
                //const res = await api.post('/employee', values);                
                dispatch(insertEmployee({ values: values }));

            } catch (error) {
                console.log(error);

            }

        }
    });
    const { values, errors, handleChange, handleSubmit, touched } = formik;
    // 
    useEffect(() => {
        //getEmpData();
        dispatch(getEmployee());
    }, []);
    useEffect(() => {
        setEmployeeLit(emps.employees)
    }, [emps])

    // const getEmpData = async () => {
    //     try {
    //         const res = await api.get("/employee");
    //         dispatch(getData({ id: 'get', values: res?.data }));
    //     } catch (error) {
    //         console.log(error);
    //     }

    // }
    const deleteHandler = (idx: string) => {
        dispatch(deleteEmployee({id:idx}));
    }
    const editHandler = (id: string) => {

    }
    return (<>
        <Container>


            <Form onSubmit={handleSubmit}>
                <Row>
                    <div className='col-2'>
                        <Form.Control type="date" id="date" name="date" value={values.date} onChange={handleChange}></Form.Control>
                        {touched.date && errors.date && <Form.Text id="date" muted>Sometging went wrong!</Form.Text>}
                    </div>
                    <div className='col-2'>
                        <Form.Control type="text" id="header" name="header" value={values.header} onChange={handleChange} placeholder="Header"></Form.Control>
                        {touched.header && errors.header && <Form.Text id="header" className="text-danger">Sometging went wrong!</Form.Text>}
                    </div>
                    <div className='col-2'>
                        <Form.Control type="text" name="employee" id="employee" value={values.employee} onChange={handleChange} placeholder="Employee Dept"></Form.Control>
                        {touched.employee && errors.employee && <Form.Text id="employee" className="text-danger">Sometging went wrong!</Form.Text>}
                    </div>
                    <div className='col-2'>
                        <Form.Control min="0" name="credit" id="credit" type="number" value={values.credit} onChange={handleChange} placeholder="Credit"></Form.Control>
                    </div>
                    <div className='col-2'>
                        <Form.Control min="0" type="number" value={values.debit} onChange={handleChange} placeholder="Debit"></Form.Control>
                    </div>
                    <div className='col-2'>
                        <Button type="submit"><i className='bi bi-plus-square-fill'></i></Button>
                    </div>

                </Row>

            </Form>
            <EmpTblHeader />
            {
                employeeList && employeeList.length > 0 && employeeList.map((Item, index) => {
                    return (
                        <Row className='row  border-bottom border-dark padding-row p-2' key={`${Item.id}_${index}`}>
                            <div className='col-2'>{Item.date}</div>
                            <div className='col-2'>{Item.header}</div>
                            <div className='col-2'>{Item.employee}</div>
                            <div className='col-2'>{Item.credit}</div>
                            <div className='col-2'> {Item.debit}</div>
                            <div className='col-2'>

                                <Button variant="primary" className="me-3" onClick={() => editHandler(Item?.id ? Item?.id : '')}>
                                    <i className='bi bi-pen' title='Edit'></i>
                                </Button>
                                <Button variant="danger" className="me-10" onClick={() => deleteHandler(Item?.id ? Item?.id : '')}><i className='bi bi-trash' title='Edit'></i></Button>
                                {/* <Button variant="success">  <i className='bi bi-save' title='Save'></i></Button>
              <Button variant="info"><i className='bi bi-x-circle' title='Cancel'></i></Button> */}
                            </div>
                        </Row>
                    )
                })
            }

        </Container>

    </>)
}

export default EmployeeData;

type buttons = { 
 className:string,
 handleClick?:React.MouseEvent,
 type:'button' | 'submit',
 txt:string
}

const Buttons=({ type, handleClick,className,txt}:buttons)=>{
    return(<>
    <button type ={type} className={className} onClick={()=>handleClick}>{txt}</button>
    </>)
}

export default Buttons;